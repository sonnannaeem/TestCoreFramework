//
//  TestCoreFramework.h
//  TestCoreFramework
//
//  Created by Sonnan Naeem on 6/15/22.
//

#import <Foundation/Foundation.h>

//! Project version number for TestCoreFramework.
FOUNDATION_EXPORT double TestCoreFrameworkVersionNumber;

//! Project version string for TestCoreFramework.
FOUNDATION_EXPORT const unsigned char TestCoreFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestCoreFramework/PublicHeader.h>


